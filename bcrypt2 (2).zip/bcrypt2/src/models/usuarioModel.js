import prisma from "../../db.js";


export const buscarUsuarioNoBanco = async () => {
  return await prisma.usuario.findMany({omit: {
    senha: true // Remove especificamente o campo senha do retorno
  }});
};

export const criarNovoUsuarioNoBanco = async (dados) => {
  return await prisma.usuario.create({
    data: dados
  });
}