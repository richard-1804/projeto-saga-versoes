import express from 'express';
import * as UsuarioController from '../controllers/usuarioController.js';

const router = express.Router();

// Mapeamento usando os nomes exatos exportados pelo Controller
router.get('/', UsuarioController.listarUsuario);
router.post('/', UsuarioController.criarUsuario);

export default router;