import * as UsuarioModel from "../models/usuarioModel.js";
import bcrypt from "bcryptjs";


export const listarUsuario = async (req, res) => {
  
  try {
    const usuarios = await UsuarioModel.buscarUsuarioNoBanco();
    res.json(usuarios);
    
  } catch (error) {
    res.status(500).json({ erro: "Erro ao buscar Usuários" });
  };
};

export const criarUsuario = async (req, res) => {
  const { nome, email, senha } = req.body;

  try {
    const saltRounds = 10;
    const senhaHash = await bcrypt.hash(senha, saltRounds);

    const usuario = await UsuarioModel.criarNovoUsuarioNoBanco({
      nome, email, senha: senhaHash
    });

    res.status(201).json({
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email
    });
  } catch (error) {
    res.status(500).json({
      erro:  `Erro ao criar usuário: ${error}`
    });
  };
};