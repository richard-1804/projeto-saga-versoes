import express from 'express';
import cors from 'cors';
import router from './src/routes/usuarioRoutes.js';

const app = express();
const PORTA = 3000;

// Middlewares obrigatórios para processar JSON e liberar o Front-End
app.use(cors());
app.use(express.json());

// Endpoints base
app.use('/usuarios', router);

// Inicialização do servidor
app.listen(PORTA, () => {
  console.log(`Servidor rodando em http://localhost:${PORTA}/usuarios`);
});